const DEFAULT_CONFIG = {
    hasSeenWelcome: false,
    enabled: true,
    ghostMode: true,
    campus: 'malabe',
    batchType: 'weekday',
    batchTypeShort: 'wd',
    groupId: '',
    customWhitelist: '',
    customBlacklist: ''
};

// Fallback logic if chrome.storage.sync is unavailable (e.g. some obscure browsers)
const storageApi = chrome.storage.sync ? chrome.storage.sync : chrome.storage.local;

storageApi.get(DEFAULT_CONFIG, (syncConfig) => {
    chrome.storage.local.get('remoteRules', (localData) => {
        window.CONFIG = syncConfig;
        window.REMOTE_RULES = localData.remoteRules || null;

        function createUIElement(htmlString) {
            const div = document.createElement('div');
            div.innerHTML = htmlString.trim();
            return div.firstChild;
        }

        function autoDetectSettings() {
            let detectedCampus = 'malabe';
            let detectedBatch = 'weekday';
            
            try {
                const headerText = document.body.innerText.toLowerCase();
                if (headerText.includes('weekend') || headerText.includes('.we.')) detectedBatch = 'weekend';
                if (headerText.includes('kandy')) detectedCampus = 'kandy';
                if (headerText.includes('kurunegala')) detectedCampus = 'kurunegala';
                if (headerText.includes('metro')) detectedCampus = 'metro';
                if (headerText.includes('matara')) detectedCampus = 'matara';
                if (headerText.includes('jaffna')) detectedCampus = 'jaffna';
            } catch(e) {}

            return { campus: detectedCampus, batch: detectedBatch };
        }

        function injectUI() {
            const overlay = createUIElement(`<div id="sliit-filter-overlay"></div>`);
            const btn = createUIElement(`<button id="sliit-filter-btn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg> Settings</button>`);

            const settingsModal = createUIElement(`
                <div class="sf-modal-container" id="sliit-filter-modal">
                    <h3>Filter Configuration <span style="font-size: 10px; color: #28a745; margin-left: auto;">Sync Active ☁️</span></h3>
                    <div class="sf-toggle-container">
                        <span class="sf-toggle-label">Module Filter <span class="sf-toggle-sub">Enable or disable filtering logic</span></span>
                        <label class="sf-switch"><input type="checkbox" id="sf-enabled" ${window.CONFIG.enabled ? 'checked' : ''}><span class="sf-slider"></span></label>
                    </div>
                    <div class="sf-toggle-container">
                        <span class="sf-toggle-label">Ghost Mode <span class="sf-toggle-sub">Fade filtered items instead of hiding</span></span>
                        <label class="sf-switch"><input type="checkbox" id="sf-ghost" ${window.CONFIG.ghostMode ? 'checked' : ''}><span class="sf-slider"></span></label>
                    </div>
                    <label class="sf-input-label">Target Campus</label>
                    <select id="sf-campus">
                        <option value="malabe">Malabe</option>
                        <option value="metro">Metro</option>
                        <option value="kandy">Kandy</option>
                        <option value="kurunegala">Kurunegala</option>
                        <option value="matara">Matara</option>
                        <option value="jaffna">Jaffna</option>
                    </select>
                    <label class="sf-input-label">Batch Classification</label>
                    <select id="sf-type">
                        <option value="weekday">Weekday (WD)</option>
                        <option value="weekend">Weekend (WE)</option>
                    </select>
                    <label class="sf-input-label">Group ID (Optional)</label>
                    <input type="text" id="sf-group" placeholder="e.g., 0301 (Leave empty for batch-wide view)">
                    
                    <label class="sf-input-label">Custom Whitelist (Comma separated)</label>
                    <input type="text" id="sf-whitelist" placeholder="e.g., Assignment, Revision">
                    
                    <label class="sf-input-label">Custom Blacklist (Comma separated)</label>
                    <input type="text" id="sf-blacklist" placeholder="e.g., Old Syllabus, Makeup">
                    
                    <div class="sliit-modal-actions">
                        <button class="sliit-btn sliit-btn-reset" id="sf-reset">Reset</button>
                        <div class="sliit-modal-actions-right">
                            <button class="sliit-btn sliit-btn-cancel" id="sf-cancel">Cancel</button>
                            <button class="sliit-btn sliit-btn-save" id="sf-save">Apply Setup</button>
                        </div>
                    </div>
                    <div class="sf-footer"><a href="https://github.com/dulithdivisekara/sliit-courseweb-cleaner/issues" target="_blank">Documentation & Issues</a></div>
                </div>
            `);

            const welcomeModal = createUIElement(`
                <div class="sf-modal-container" id="sliit-welcome-modal">
                    <div class="sf-welcome-header">
                        <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                        <h3>Extension Initialized</h3>
                    </div>
                    <p class="sf-welcome-text">The SLIIT Courseweb Module Cleaner v7.0 is now active. Configurations will sync across your devices.</p>
                    <div class="sf-welcome-credit" id="sf-auto-detect-area">
                        <strong>Smart Auto-Detect:</strong><br>
                        We detected your campus and batch. Please confirm in the settings.
                    </div>
                    <div class="sliit-modal-actions">
                        <button class="sliit-btn sliit-btn-save" id="sf-welcome-start">Review & Configure Setup</button>
                    </div>
                </div>
            `);

            document.body.appendChild(overlay);
            document.body.appendChild(btn);
            document.body.appendChild(settingsModal);
            document.body.appendChild(welcomeModal);

            document.getElementById('sf-campus').value = window.CONFIG.campus;
            document.getElementById('sf-type').value = window.CONFIG.batchType;
            document.getElementById('sf-group').value = window.CONFIG.groupId;
            document.getElementById('sf-whitelist').value = window.CONFIG.customWhitelist || '';
            document.getElementById('sf-blacklist').value = window.CONFIG.customBlacklist || '';

            const showSettings = () => { settingsModal.style.display = 'block'; overlay.style.display = 'block'; };
            const closeModals = () => { settingsModal.style.display = 'none'; welcomeModal.style.display = 'none'; overlay.style.display = 'none'; };

            btn.onclick = showSettings;
            document.getElementById('sf-cancel').onclick = closeModals;
            overlay.onclick = closeModals;

            if (!window.CONFIG.hasSeenWelcome) {
                const detected = autoDetectSettings();
                document.getElementById('sf-campus').value = detected.campus;
                document.getElementById('sf-type').value = detected.batch;
                
                welcomeModal.style.display = 'block';
                overlay.style.display = 'block';
                document.getElementById('sf-welcome-start').onclick = () => {
                    storageApi.set({ hasSeenWelcome: true }, () => {
                        welcomeModal.style.display = 'none';
                        showSettings();
                    });
                };
            }

            document.getElementById('sf-reset').onclick = () => {
                if(confirm('Are you sure you want to reset all configurations to default?')) {
                    storageApi.clear(() => location.reload());
                }
            };

            document.getElementById('sf-save').onclick = () => {
                const newType = document.getElementById('sf-type').value;
                const newSettings = {
                    enabled: document.getElementById('sf-enabled').checked,
                    ghostMode: document.getElementById('sf-ghost').checked,
                    campus: document.getElementById('sf-campus').value,
                    batchType: newType,
                    batchTypeShort: newType === 'weekend' ? 'we' : 'wd',
                    groupId: document.getElementById('sf-group').value.trim(),
                    customWhitelist: document.getElementById('sf-whitelist').value.trim(),
                    customBlacklist: document.getElementById('sf-blacklist').value.trim()
                };
                storageApi.set(newSettings, () => location.reload());
            };
        }

        // Initialize UI and Core
        let isCleaning = false;
        function runClean() {
            if (isCleaning) return;
            isCleaning = true;
            requestAnimationFrame(() => {
                cleanCoursePage();
                isCleaning = false;
            });
        }

        window.addEventListener('load', () => {
            runClean();
            injectUI();
            
            // Replaces fragile setTimeout polling with robust MutationObserver
            const observer = new MutationObserver((mutations) => {
                let shouldRun = false;
                for (let m of mutations) {
                    if (m.addedNodes.length > 0 && m.target.className !== 'sf-modal-container') {
                        shouldRun = true;
                        break;
                    }
                }
                if (shouldRun) runClean();
            });
            
            const courseContent = document.querySelector('.course-content') || document.body;
            observer.observe(courseContent, { childList: true, subtree: true });
        });
    });
});